
// Auto-seed data for admin: teachers, students, and appointments
const seedTeachers = [
    { name: "Amit Sharma", dept: "Computer Science", subject: "Data Structures", email: "teacher1@example.com", password: "Pass123!" },
    { name: "Ravi Kumar", dept: "Mathematics", subject: "Algebra", email: "teacher2@example.com", password: "Pass123!" },
    { name: "Priya Nair", dept: "Physics", subject: "Quantum Mechanics", email: "teacher3@example.com", password: "Pass123!" },
    { name: "Sunil Gupta", dept: "Chemistry", subject: "Organic Chemistry", email: "teacher4@example.com", password: "Pass123!" },
    { name: "Meena Iyer", dept: "English", subject: "Literature", email: "teacher5@example.com", password: "Pass123!" }
];

const seedStudents = [
    { name: "Rohan Das", dept: "Computer Science", email: "student1@example.com", password: "Pass123!" },
    { name: "Sneha Verma", dept: "Mathematics", email: "student2@example.com", password: "Pass123!" },
    { name: "Arjun Patel", dept: "Physics", email: "student3@example.com", password: "Pass123!" },
    { name: "Kavya Menon", dept: "Chemistry", email: "student4@example.com", password: "Pass123!" },
    { name: "Vikram Joshi", dept: "English", email: "student5@example.com", password: "Pass123!" }
];

async function seedData(auto=false) {
    if (!firebase.auth().currentUser) return;
    const adminProfile = await getUserProfile(firebase.auth().currentUser.uid);
    if (!adminProfile || adminProfile.role !== "admin") return;

    const adminEmail = adminProfile.email;
    const adminPassword = auto ? "Pass123!" : prompt("Enter admin password:");

    // Teachers
    for (const t of seedTeachers) {
        try {
            const cred = await firebase.auth().createUserWithEmailAndPassword(t.email, t.password);
            const uid = cred.user.uid;
            await firebase.firestore().collection("users").doc(uid).set({
                name: t.name, email: t.email, role: "teacher", dept: t.dept, approved: true, createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });
            await firebase.firestore().collection("teachers").doc(uid).set({ name: t.name, dept: t.dept, subject: t.subject, uid });
            await firebase.auth().signInWithEmailAndPassword(adminEmail, adminPassword);
        } catch {}
    }

    // Students
    for (const s of seedStudents) {
        try {
            const cred = await firebase.auth().createUserWithEmailAndPassword(s.email, s.password);
            const uid = cred.user.uid;
            await firebase.firestore().collection("users").doc(uid).set({
                name: s.name, email: s.email, role: "student", dept: s.dept, approved: true, createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });
            await firebase.auth().signInWithEmailAndPassword(adminEmail, adminPassword);
        } catch {}
    }

    // Appointments
    const teacherDocs = await firebase.firestore().collection("teachers").get();
    const studentDocs = await firebase.firestore().collection("users").where("role", "==", "student").get();
    const teachersArr = teacherDocs.docs.map(d => ({ uid: d.id, ...d.data() }));
    const studentsArr = studentDocs.docs.map(d => ({ uid: d.id, ...d.data() }));

    for (const student of studentsArr) {
        for (let i=0; i<2; i++) {
            const randomTeacher = teachersArr[Math.floor(Math.random() * teachersArr.length)];
            const dateTime = new Date();
            dateTime.setDate(dateTime.getDate() + (i+1));
            await firebase.firestore().collection("appointments").add({
                studentUid: student.uid,
                teacherUid: randomTeacher.uid,
                datetime: dateTime.toISOString().slice(0, 16).replace("T", " "),
                status: "pending",
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });
        }
    }

    if (!auto) alert("Seeding completed.");
}

// Auto-run on first admin login if no teachers exist
firebase.auth().onAuthStateChanged(async user => {
    if (user) {
        const profile = await getUserProfile(user.uid);
        if (profile && profile.role === "admin") {
            const tcount = await firebase.firestore().collection("teachers").get();
            if (tcount.empty) await seedData(true);
        }
    }
});
